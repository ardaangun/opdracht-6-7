let product = prompt("Hoeveel kost het product dat je wilt kopen?");
let budget = 100;

if(budget > product) {
    console.log("mf ik heb genoeg geld");
} else {
    console.log("ik heb niet genoeg geld");
}
